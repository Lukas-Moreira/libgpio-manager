#pragma once

/**
 * @file gpio_types.hpp
 * @brief GPIO Manager Types of pins modes and values
 * 
 */
namespace gpio_manager {

    /**
     * 0 - Input mode
     * 1 - Output mode
     */
    enum class PinDirection {INPUT = 0, OUTPUT = 1};

    /**
     * 0 - Low voltage level
     * 1 - High voltage level
     */
    enum class PinValue {LOW = 0, HIGH = 1};

} // namespace gpio_manager