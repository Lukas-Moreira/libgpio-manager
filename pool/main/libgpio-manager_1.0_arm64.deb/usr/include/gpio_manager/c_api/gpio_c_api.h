#pragma once 

#ifdef __cplusplus
 extern "C" {
#endif

/**
 * @brief Handler for GPIO operations
 */
typedef void* gpio_handle_t;

/**
 * @brief GPIO direction enumeration
 */
typedef enum {
    GPIO_DIR_INPUT = 0,
    GPIO_DIR_OUTPUT = 1
} gpio_direction_t;

/**
 * @brief GPIO value enumeration
 */
typedef enum {
    LOW = 0,
    HIGH = 1
} gpio_value_t;

/* lifecycle */
gpio_handle_t gpio_create(void);
void gpio_destroy(gpio_handle_t handle);

/**
 * @brief Set the mode of a GPIO pin
 * 
 * @param handle    Handle to GPIO manager.
 * @param pin       Pin indentifier (e.g., "GPIO1").
 * @param direction Direction to set (input/output).
 * @return int 
 */
int gpio_set_mode(gpio_handle_t handle, const char* pin, gpio_direction_t direction);

/**
 * @brief Write a value to a GPIO pin
 * 
 * @param handle    Handle to GPIO manager.
 * @param pin       Pin indentifier (e.g., "GPIO1").
 * @param value     Value to write (high/low).
 * @return int 
 */
int gpio_write(gpio_handle_t handle, const char* pin, gpio_value_t value);

/**
 * @brief Read a value from a GPIO pin
 * 
 * @param handle    Handle to GPIO manager.
 * @param pin       Pin indentifier (e.g., "GPIO1").
 * @param value     Pointer to store the read value (high/low).
 * @return int 
 */
int gpio_read(gpio_handle_t handle, const char* pin, gpio_value_t* value);

#ifdef __cplusplus
 }
#endif