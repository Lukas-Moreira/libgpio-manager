#pragma once 

#include <string>

using namespace std;

namespace gpio_manager {
    /**
     * @brief Supported Board Types
     * 
     */
    enum class BoardType {
        Auto = 0,
        Rock_5c,
        UnknownLinux,
        Controller,
    };

    /**
     * @brief Detect the board type
     * 
     * @return BoardType Detected board type
     */
    BoardType detect_board_type();

    /**
     * @brief Convert BoardType enum to string
     * 
     * @param BoardType Board type enum
     * @return string String representation of the board type
     */
    string board_type_to_string(BoardType);
}