#pragma once 
#include <memory>
#include "./drivers/igpio_driver.hpp"
#include "./drivers/igpio_named_driver.hpp"

using namespace std;

namespace gpio_manager {

    class Gpio {
        public:
            explicit Gpio(unique_ptr<IGpioDriver> driver);  // Constructor that takes ownership of a GPIO driver

            void set_mode(int pin, PinDirection direction); // Set the mode of a GPIO pin
            // void write(int pin, PinValue value);            // Write a value to a GPIO pin
            // PinValue read(int pin);                         // Read the value from a GPIO pin

            void set_mode(const string& name, PinDirection direction); // Set the mode of a named GPIO pin
            void write(const string& name, PinValue value);            // Write a value to a
            PinValue read(const string& name);                         // Read the value from a named GPIO pin

            private: 
                unique_ptr<IGpioDriver> driver_;            // Unique pointer to the GPIO driver
    };
} // namespace gpio_manager

