#pragma once

#include <string>
#include <unordered_map>

#include "../board.hpp"
#include "igpio_driver.hpp"
#include "igpio_named_driver.hpp"

using namespace std;

struct gpiod_chip;
struct gpiod_line;

namespace gpio_manager {

    class LinuxGpiodDriver : public IGpioDriver, public IGpioNamedDriver {
        public:
            explicit LinuxGpiodDriver(BoardType board = BoardType::Auto);
            LinuxGpiodDriver(const string& chip_name, BoardType board = BoardType::Auto);
            ~LinuxGpiodDriver() override;

            void set_mode(int pin, PinDirection direction) override;
            void write(int pin, PinValue value) override;
            PinValue read(int pin) override;

            void set_mode(const string& pin_name, PinDirection direction);
            void write(const string& pin_name, PinValue value);
            PinValue read(const string& pin_name);

        private:
            void ensure_chip();
            void ensure_line(int pin);
            void release_line(int pin);

            int resolve_offset_by_name(const string& pin_name);

        private:
            string chip_name_;

            BoardType board_ = BoardType::Auto;

            ::gpiod_chip* chip_ = nullptr;
            ::gpiod_line* lines_[1024] = {nullptr};
            bool requested_[1024] = {false};
            PinDirection direction_[1024] = {};

            // Cache for name to offset mapping
            unordered_map<string, int> name_to_offset_;
    };

} // namespace gpio_manager
