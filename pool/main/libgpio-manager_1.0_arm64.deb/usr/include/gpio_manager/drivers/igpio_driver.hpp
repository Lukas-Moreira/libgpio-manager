#pragma once 
#include "../gpio_types.hpp"

namespace gpio_manager{

    /**
     * @class Interface for GPIO drivers
     */
    class IGpioDriver{
        public:
            virtual ~IGpioDriver() = default;

            virtual void set_mode(int pin, PinDirection direction) = 0; // Set pin mode (input/output)
            virtual void write(int pin, PinValue value) = 0;            // Write value to pin (high/low)
            virtual PinValue read(int pin) = 0;                         // Read value from pin (high/low)

    };
} //namespace gpio_manager
