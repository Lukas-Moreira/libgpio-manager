#pragma once

#include <string>
#include "../gpio_types.hpp"

using namespace std;

namespace gpio_manager
{

    class IGpioNamedDriver 
    {
    public:
        virtual ~IGpioNamedDriver () = default;

        virtual void set_mode(const string& pin_name, PinDirection mode) = 0;
        virtual void write(const string& pin_name, PinValue value) = 0;
        virtual PinValue read(const string& pin_name) = 0;

    };

} // namespace gpio_manager