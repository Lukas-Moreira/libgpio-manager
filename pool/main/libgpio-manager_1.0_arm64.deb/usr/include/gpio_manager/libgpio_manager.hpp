#pragma once
#include <memory>
#include "gpio.hpp"

std::unique_ptr<gpio_manager::Gpio> create_gpio();

using namespace gpio_manager;